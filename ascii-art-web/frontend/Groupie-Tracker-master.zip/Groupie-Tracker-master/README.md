Description: This is a web application made using Golang, HTML and CSS that allows a user to get artist info when clicked upon it's icon/name.

Authors: Abdul Raheem Khan and Jason Asante-Twumasi

Usage: how to run

1.Git clone the groupie-tracker repository

2.In your terminal, run "go run ." in the groupie-tracker repository

3.Now open a browser and enter "localhost:8080" into the URL

4.Click on the artists' icon or name

5.You will be redirected to a page with all the relevant artist info